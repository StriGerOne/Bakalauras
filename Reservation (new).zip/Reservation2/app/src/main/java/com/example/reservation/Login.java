package com.example.reservation;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.reservation.Controllers.RESTController;

import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText LoginUser = findViewById(R.id.login_name);
        EditText LoginPass = findViewById(R.id.login_password);
        Button LoginButton = findViewById(R.id.login_button);
        Button RegisterButton = findViewById(R.id.login_reg_button);

        LoginButton.setOnClickListener(v -> {
           String username = LoginUser.getText().toString();
           String password = LoginPass.getText().toString();

           String json = "{\"login\"" + LoginUser.getText().toString() + "\", \"psw\"" + LoginPass.getText().toString() + "\"}";

            if (username.equals("") || password.equals(""))
                Toast.makeText(Login.this, "Please enter all fields", Toast.LENGTH_SHORT).show();

            Executor executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());
            String[] response = {""};

            executor.execute(() -> {
                String url = "http://192.168.8.101:8080/authenticate";
                try {
                    response[0] = RESTController.sendPost(url, json);
                    System.out.println(response[0]);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            });
            handler.post(() -> {
                System.out.println(response[0]);
                if (response[0] !=null){
                    Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, MainWindow.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Bad login or password", Toast.LENGTH_SHORT).show();
                }
            });
        });


        RegisterButton.setOnClickListener(v -> startActivity(new Intent(Login.this, Register.class)));
    }
}